DROP DATABASE IF EXISTS `stk_suite`;
DROP DATABASE IF EXISTS `stk_unit`;
DROP DATABASE IF EXISTS `meta_schema`;
DROP DATABASE IF EXISTS `test_stk_unit`;
DROP DATABASE IF EXISTS `test_stk_unit_assertions`;

COMMIT;
