/*
    SQLToolKit/Unit
	Copyright Federico Razzoli  2012, 2013
	
	This file is part of SQLToolKit/Unit.
	
    SQLToolKit/Unit is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, version 3 of the License.
	
    SQLToolKit/Unit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.
	
    You should have received a copy of the GNU Affero General Public License
    along with SQLToolKit/Unit.  If not, see <http://www.gnu.org/licenses/>.
*/


DELIMITER ||


-- make the server as strict as possible
SET @__stk_u_old_SQL_MODE = @@session.SQL_MODE;
SET @@session.SQL_MODE = 'ERROR_FOR_DIVISION_BY_ZERO,NO_ZERO_DATE,NO_ZERO_IN_DATE,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION,ONLY_FULL_GROUP_BY,STRICT_ALL_TABLES,STRICT_TRANS_TABLES';
SET @__stk_u_old_sql_warnings = @@session.sql_warnings;
SET @@session.sql_warnings = TRUE;
SET @__stk_u_old_sql_notes = @@session.sql_notes;
SET @@session.sql_notes = TRUE;
SET @__stk_u_old_unique_checks = @@session.unique_checks;
SET @@session.unique_checks = TRUE;
SET @__stk_u_old_foreign_key_checks = @@session.foreign_key_checks;
SET @@session.foreign_key_checks = TRUE;
-- MariaDB and MySQL > 5.1 support innodb_strict_mode
SET /*!50200 @__stk_u_old_innodb_strict_mode = @@session.innodb_strict_mode, */ @__stk_u_tmp = NULL;
SET /*!50200 @@session.innodb_strict_mode = TRUE, */ @__stk_u_tmp = NULL;
SET /*M! @__stk_u_old_innodb_strict_mode = @@session.innodb_strict_mode, */ @__stk_u_tmp = NULL;
SET /*M! @@session.innodb_strict_mode = TRUE, */ @__stk_u_tmp = NULL;
SET @__stk_u_updatable_views_with_limit = @@session.updatable_views_with_limit;
SET @@session.updatable_views_with_limit = FALSE;
SET @__stk_u_old_character_set_server = @@session.character_set_server;
SET @@session.character_set_server = 'utf8';
SET @__stk_u_old_collation_server = @@session.collation_server;
SET @@session.collation_server = 'utf8_general_ci';


-- create & select db
DROP DATABASE IF EXISTS `test_stk_unit`;
CREATE DATABASE `test_stk_unit`
	DEFAULT CHARACTER SET = 'utf8'
	DEFAULT COLLATE = 'utf8_general_ci';
USE `test_stk_unit`;


CREATE TABLE `run_routine`
(
	`name` CHAR(50) NOT NULL
)
	ENGINE   = 'MEMORY',
	DEFAULT CHARACTER SET = ascii,
	COLLATE = ascii_bin,
	COMMENT = 'Test data';


-- to check if this is called, check @a
CREATE PROCEDURE call_me()
	LANGUAGE SQL
BEGIN
	SET @a = TRUE;
END;



CREATE PROCEDURE before_all_tests()
	LANGUAGE SQL
	COMMENT 'Test that before_all_tests() is called'
BEGIN
	TRUNCATE TABLE `run_routine`;
	INSERT HIGH_PRIORITY INTO `run_routine` (`name`) VALUES ('before_all_tests');
END;

CREATE PROCEDURE set_up()
	LANGUAGE SQL
	COMMENT 'Test that set_up() is called'
BEGIN
	INSERT HIGH_PRIORITY INTO `run_routine` (`name`) VALUES ('set_up');
END;

CREATE PROCEDURE tear_down()
	LANGUAGE SQL
	COMMENT 'Test that tear_down() is called'
BEGIN
	INSERT HIGH_PRIORITY INTO `run_routine` (`name`) VALUES ('tear_down');
END;

CREATE PROCEDURE after_all_tests()
	LANGUAGE SQL
	COMMENT 'Test that after_all_tests() is called'
BEGIN
	INSERT HIGH_PRIORITY INTO `run_routine` (`name`) VALUES ('after_all_tests');
END;

CREATE PROCEDURE test_a()
	LANGUAGE SQL
	COMMENT 'First. Triggers setup & teardown'
BEGIN
	DO NULL;
END;

CREATE PROCEDURE test_setup_teardown()
	LANGUAGE SQL
	COMMENT 'Test set_up tear_down before/after_all_tests'
BEGIN
	CALL `stk_unit`.assert_true(
			(SELECT COUNT(*) > 0 FROM `run_routine` WHERE `name` = 'set_up'),
			'set_up() not executed'
		);
	CALL `stk_unit`.assert_true(
			(SELECT COUNT(*) > 0 FROM `run_routine` WHERE `name` = 'tear_down'),
			'tear_down() not executed'
		);
	CALL `stk_unit`.assert_true(
			(SELECT COUNT(*) > 0 FROM `run_routine` WHERE `name` = 'before_all_tests'),
			'before_all_tests() not executed'
		);
	/*
		How can we test this?
	CALL `stk_unit`.assert_true(
			(SELECT COUNT(*) > 0 FROM `run_routine` WHERE `name` = 'after_all_tests'),
			'after_all_tests() not executed'
		);
	*/
END;

CREATE PROCEDURE test_install()
	LANGUAGE SQL
	COMMENT 'Test meta_schema'
BEGIN
	-- STK/Unit metadata
	CALL `stk_unit`.`assert_table_exists`('meta_schema', 'LIBRARIES', 'meta_schema.LIBRARIES not created');
	CALL `stk_unit`.`assert_row_exists`('meta_schema', 'LIBRARIES', 'LIB_NAME', 'STK/Unit', 'Missing STK/Unit row in LIBRARIES');
	
	-- mirror views
	CALL `stk_unit`.`assert_row_exists`('meta_schema', 'TEST_SUITE', 'TEST_SUITE_NAME', 'stk_unit', NULL);
	CALL `stk_unit`.`assert_row_exists`('meta_schema', 'TEST_CASE', 'TEST_CASE_NAME', 'test_stk_unit', NULL);
	CALL `stk_unit`.`assert_row_exists`('meta_schema', 'BASE_TEST', 'BASE_TEST_NAME', 'test_install', NULL);
END;

CREATE PROCEDURE test_show_test_suites()
	LANGUAGE SQL
	COMMENT 'Test show_test_suites()'
BEGIN
	DECLARE `num` INTEGER UNSIGNED DEFAULT 0;
	
	CALL `stk_unit`.`show_test_suites`(NULL);
	SET `num` = FOUND_ROWS();
	CALL `stk_unit`.assert_true(`num` > 0, CONCAT('show_test_suites(NULL) returned no results'));
	
	CALL `stk_unit`.`show_test_suites`('%');
	SET `num` = FOUND_ROWS();
	CALL `stk_unit`.assert_true(`num` > 0, CONCAT('show_test_suites(''%'') returned no results'));
END;

CREATE PROCEDURE test_show_test_cases()
	LANGUAGE SQL
	COMMENT 'Test show_test_cases()'
BEGIN
	DECLARE `num` INTEGER UNSIGNED DEFAULT 0;
	
	CALL `stk_unit`.`show_test_cases`(NULL);
	SET `num` = FOUND_ROWS();
	CALL `stk_unit`.assert_true(`num` > 0, CONCAT('show_test_cases(NULL) returned no results'));
	
	CALL `stk_unit`.`show_test_cases`('%');
	SET `num` = FOUND_ROWS();
	CALL `stk_unit`.assert_true(`num` > 0, CONCAT('show_test_cases(''%'') returned no results'));
END;

CREATE PROCEDURE test_show_base_tests()
	LANGUAGE SQL
	COMMENT 'Test show_base_tests()'
BEGIN
	DECLARE `num` INTEGER UNSIGNED DEFAULT 0;
	
	-- first param NULL
	
	CALL `stk_unit`.`show_base_tests`(NULL, NULL);
	SET `num` = FOUND_ROWS();
	CALL `stk_unit`.assert_true(`num` > 0, CONCAT('show_base_tests(NULL) returned no results'));
	
	CALL `stk_unit`.`show_base_tests`(NULL, '%');
	SET `num` = FOUND_ROWS();
	CALL `stk_unit`.assert_true(`num` > 0, CONCAT('show_base_tests(''%'') returned no results'));
	
	-- second param set
	
	CALL `stk_unit`.`show_base_tests`('test_stk_unit', NULL);
	SET `num` = FOUND_ROWS();
	CALL `stk_unit`.assert_true(`num` > 0, CONCAT('show_base_tests(''test_stk_unit'', NULL) returned no results'));
	
	CALL `stk_unit`.`show_base_tests`('test_stk_unit', '%');
	SET `num` = FOUND_ROWS();
	CALL `stk_unit`.assert_true(`num` > 0, CONCAT('show_base_tests(''test_stk_unit'', ''%'') returned no results'));
END;

CREATE PROCEDURE test_databases_character_sets()
	LANGUAGE SQL
	COMMENT 'Test default DBs charsets'
BEGIN
	-- used for both charsets and collations
	DECLARE default_character_set CHAR(100) DEFAULT NULL;
	
	SET default_character_set = (SELECT `DEFAULT_CHARACTER_SET_NAME` FROM `information_schema`.`SCHEMATA` WHERE `SCHEMA_NAME` = 'stk_unit');
	CALL `stk_unit`.`assert_equal`(
			default_character_set,
			'utf8',
			CONCAT('stk_unit db DEFAULT CHARACTER SET is ', IFNULL(default_character_set, ''))
		);
	
	SET default_character_set = (SELECT `DEFAULT_COLLATION_NAME` FROM `information_schema`.`SCHEMATA` WHERE `SCHEMA_NAME` = 'stk_unit');
	CALL `stk_unit`.`assert_equal`(
			default_character_set,
			'utf8_general_ci',
			CONCAT('stk_unit db DEFAULT COLLATION is ', IFNULL(default_character_set, ''))
		);
	
	SET default_character_set = (SELECT `DEFAULT_CHARACTER_SET_NAME` FROM `information_schema`.`SCHEMATA` WHERE `SCHEMA_NAME` = 'stk_suite');
	CALL `stk_unit`.`assert_equal`(
			default_character_set,
			'utf8',
			CONCAT('stk_suite db DEFAULT CHARACTER SET is ', IFNULL(default_character_set, ''))
		);
	
	SET default_character_set = (SELECT `DEFAULT_COLLATION_NAME` FROM `information_schema`.`SCHEMATA` WHERE `SCHEMA_NAME` = 'stk_suite');
	CALL `stk_unit`.`assert_equal`(
			default_character_set,
			'utf8_general_ci',
			CONCAT('stk_suite db DEFAULT COLLATION is ', IFNULL(default_character_set, ''))
		);
	
	SET default_character_set = (SELECT `DEFAULT_CHARACTER_SET_NAME` FROM `information_schema`.`SCHEMATA` WHERE `SCHEMA_NAME` = 'meta_schema');
	CALL `stk_unit`.`assert_equal`(
			default_character_set,
			'utf8',
			CONCAT('meta_schema db DEFAULT CHARACTER SET is ', IFNULL(default_character_set, ''))
		);
	
	SET default_character_set = (SELECT `DEFAULT_COLLATION_NAME` FROM `information_schema`.`SCHEMATA` WHERE `SCHEMA_NAME` = 'meta_schema');
	CALL `stk_unit`.`assert_equal`(
			default_character_set,
			'utf8_general_ci',
			CONCAT('meta_schema db DEFAULT COLLATION is ', IFNULL(default_character_set, ''))
		);
END;

CREATE PROCEDURE test_func_character_sets()
	LANGUAGE SQL
	COMMENT 'Test return value of functions'
BEGIN
	CALL `stk_unit`.`assert_false`(
			(SELECT EXISTS (SELECT 1 FROM `information_schema`.`ROUTINES` WHERE `ROUTINE_SCHEMA` = 'stk_unit' AND (`CHARACTER_SET_NAME` NOT LIKE 'utf8' AND `CHARACTER_SET_NAME` IS NOT NULL))),
			'At least 1 func returns not utf8'
		);
	
	-- if first assert fails this is redundant, but who cares
	CALL `stk_unit`.`assert_false`(
			(SELECT EXISTS (SELECT 1 FROM `information_schema`.`ROUTINES` WHERE `ROUTINE_SCHEMA` = 'stk_unit' AND (`COLLATION_NAME` NOT LIKE 'utf8_general_ci' AND `COLLATION_NAME` IS NOT NULL))),
			'At least 1 func returns not utf8_general_ci'
		);
END;

CREATE PROCEDURE test_xml_replace()
	LANGUAGE SQL
	COMMENT 'Test xml_encode()'
BEGIN
	CALL `stk_unit`.`assert_equals`(stk_unit.xml_encode('abc'), 'abc', NULL);
	CALL `stk_unit`.`assert_equals`(stk_unit.xml_encode(''), '', NULL);
	CALL `stk_unit`.`assert_null`(stk_unit.xml_encode(NULL), NULL);
	
	CALL `stk_unit`.`assert_equals`(stk_unit.xml_encode('&<'), '&amp;&lt;', NULL);
	CALL `stk_unit`.`assert_equals`(stk_unit.xml_encode('&amp;&lt;'), '&amp;amp;&amp;lt;', NULL);
END;

CREATE PROCEDURE test_ns_str()
	LANGUAGE SQL
	COMMENT 'Test quote_name()'
BEGIN
	CALL `stk_unit`.`assert_equals`(stk_unit.ns_str("x"), "'x'", 'Incorrect quoting');
	CALL `stk_unit`.`assert_equals`(stk_unit.ns_str("x'y"), "'x\\'y'", 'Incorrect escape');
	
	CALL `stk_unit`.`assert_equals`(stk_unit.ns_str(""), "''", 'Empty quotes expected');
	CALL `stk_unit`.`assert_equals`(stk_unit.ns_str(NULL), "NULL", 'For NULL value, string "NULL" should be returned');
END;

CREATE PROCEDURE test_quote_name()
	LANGUAGE SQL
	COMMENT 'Test quote_name()'
BEGIN
	CALL `stk_unit`.`assert_equals`(stk_unit.quote_name('x'), '`x`', 'Incorrect quoting');
	CALL `stk_unit`.`assert_equals`(stk_unit.quote_name('x`y'), '`x``y`', 'Incorrect escape');
	
	CALL `stk_unit`.`assert_equals`(stk_unit.quote_name(''), '``', 'Empty name expected');
	CALL `stk_unit`.`assert_equals`(stk_unit.quote_name(NULL), '``', 'For NULL value, empty name should be returned');
END;

CREATE PROCEDURE test_config_set_get()
	LANGUAGE SQL
	COMMENT 'Test config_set(), config_get()'
BEGIN
	DECLARE `res` TEXT;
	DECLARE `val` TEXT;
	DECLARE `zero` CHAR(1) DEFAULT '0';
	DECLARE `unus` CHAR(1) DEFAULT '1';
	
	-- set & get valid option
	CALL `stk_unit`.`config_set`('show_err', `zero`);
	SET `res` = `stk_unit`.`config_get`('show_err');
	CALL `stk_unit`.`assert_equals`(`res`, `zero`,
		CONCAT('Incorrect option value; should be ', IFNULL(`zero`, 'NULL'), ', got: ', IFNULL(`res`, 'NULL')));
	
	-- change & read again same option
	CALL `stk_unit`.`config_set`('show_err', `unus`);
	SET `res` = `stk_unit`.`config_get`('show_err');
	CALL `stk_unit`.`assert_equals`(`res`, `unus`,
		CONCAT('Incorrect option value; should be ', IFNULL(`unus`, 'NULL'), ', got: ', IFNULL(`res`, 'NULL')));
END;

CREATE PROCEDURE test_config_set_invalid()
	LANGUAGE SQL
	COMMENT 'Test config_set()'
BEGIN
	-- try to set invalid option
	/*!50500
		CALL `stk_unit`.`expect_any_exception`();
	*/
	CALL `stk_unit`.`config_set`('not-exists', '1');
END;

CREATE PROCEDURE test_log_result()
	LANGUAGE SQL
	COMMENT 'Test log_result()'
BEGIN
	-- number of "artificial" test results
	DECLARE num_entries_art  BIGINT UNSIGNED     DEFAULT NULL;
	-- identifies an "artificial" test result, created by the test
	DECLARE test_note        CHAR(50)            DEFAULT 'Intentionally generated by the test';
	
	-- delete "artificial" results
	-- (yes, we have to do this before AND after)
	DELETE
		FROM `stk_unit`.`test_results`
		WHERE `msg` = test_note;
	
	-- insert "artificial" results
	CALL `stk_unit`.log_result('pass',       test_note);
	CALL `stk_unit`.log_result('fail',       test_note);
	CALL `stk_unit`.log_result('exception',  test_note);
	
	-- "artificial" results must be 3
	SELECT COUNT(*)
		FROM `stk_unit`.`test_results`
		WHERE `msg` = test_note
		INTO `num_entries_art`;
	CALL `stk_unit`.assert_true(num_entries_art = 3, CONCAT('Created entries: ', num_entries_art, ' instead of 3'));
	
	-- delete "artificial" results
	DELETE
		FROM `stk_unit`.`test_results`
		WHERE `msg` = test_note;
END;

CREATE PROCEDURE test_ignore_all_exceptions()
	LANGUAGE SQL
	COMMENT 'Test ignore_all_exceptions()'
BEGIN
	CALL `stk_unit`.ignore_all_exceptions();
	CALL `stk_unit`.assert_true(
			EXISTS (SELECT COUNT(*) FROM `stk_unit`.`expect`),
			'No "ignore" expectation created'
		);
END;

CREATE PROCEDURE test_expect_any_exception()
	LANGUAGE SQL
	COMMENT 'Test expect_any_exception()'
BEGIN
	CALL `stk_unit`.expect_any_exception();
	CALL `stk_unit`.assert_true(
			EXISTS (SELECT COUNT(*) FROM `stk_unit`.`expect`),
			'No "expect" expectation created'
		);
	-- produce exception to avoid fail
	SELECT `not_exists` FROM `not_exists`;
END;


-- restore session variables
SET @@session.SQL_MODE = @__stk_u_old_SQL_MODE;
SET @@session.sql_warnings = @__stk_u_old_sql_warnings;
SET @@session.sql_notes = @__stk_u_old_sql_notes;
SET @@session.unique_checks = @__stk_u_old_unique_checks;
SET @@session.foreign_key_checks = @__stk_u_old_foreign_key_checks;
SET /*!50200  @@session.innodb_strict_mode = @__stk_u_old_innodb_strict_mode, */  @__stk_u_tmp = NULL;
SET /*M!      @@session.innodb_strict_mode = @__stk_u_old_innodb_strict_mode, */  @__stk_u_tmp = NULL;
SET @@session.updatable_views_with_limit = @__stk_u_updatable_views_with_limit;
SET @@session.character_set_server = @__stk_u_old_character_set_server;
SET @@session.collation_server = @__stk_u_old_collation_server;
-- free user variables
SET @__stk_u_old_SQL_MODE = NULL
	, @__stk_u_old_sql_warnings = NULL
	, @__stk_u_old_sql_notes = NULL
	, @__stk_u_old_unique_checks = NULL
	, @__stk_u_old_foreign_key_checks = NULL
	, @__stk_u_old_innodb_strict_mode = NULL
	, @__stk_u_updatable_views_with_limit = NULL
	, @__stk_u_old_character_set_server = NULL
	, @__stk_u_old_collation_server = NULL;


COMMIT;


||
DELIMITER ;

