/*
    SQLToolKit/Unit
	Copyright Federico Razzoli  2012, 2013
	
	This file is part of SQLToolKit/Unit.
	
    SQLToolKit/Unit is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, version 3 of the License.
	
    SQLToolKit/Unit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.
	
    You should have received a copy of the GNU Affero General Public License
    along with SQLToolKit/Unit.  If not, see <http://www.gnu.org/licenses/>.
*/


DELIMITER ||

##begin


-- make the server as strict as possible
SET @__stk_u_old_SQL_MODE = @@session.SQL_MODE;
SET @@session.SQL_MODE = 'ERROR_FOR_DIVISION_BY_ZERO,NO_ZERO_DATE,NO_ZERO_IN_DATE,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION,ONLY_FULL_GROUP_BY,STRICT_ALL_TABLES,STRICT_TRANS_TABLES';
SET @__stk_u_old_sql_warnings = @@session.sql_warnings;
SET @@session.sql_warnings = TRUE;
SET @__stk_u_old_sql_notes = @@session.sql_notes;
SET @@session.sql_notes = TRUE;
SET @__stk_u_old_unique_checks = @@session.unique_checks;
SET @@session.unique_checks = TRUE;
SET @__stk_u_old_foreign_key_checks = @@session.foreign_key_checks;
SET @@session.foreign_key_checks = TRUE;
-- MariaDB and MySQL > 5.1 support innodb_strict_mode
SET /*!50200 @__stk_u_old_innodb_strict_mode = @@session.innodb_strict_mode, */ @__stk_u_tmp = NULL;
SET /*!50200 @@session.innodb_strict_mode = TRUE, */ @__stk_u_tmp = NULL;
SET /*M! @__stk_u_old_innodb_strict_mode = @@session.innodb_strict_mode, */ @__stk_u_tmp = NULL;
SET /*M! @@session.innodb_strict_mode = TRUE, */ @__stk_u_tmp = NULL;
SET @__stk_u_updatable_views_with_limit = @@session.updatable_views_with_limit;
SET @@session.updatable_views_with_limit = FALSE;
SET @__stk_u_old_character_set_server = @@session.character_set_server;
SET @@session.character_set_server = 'utf8';
SET @__stk_u_old_collation_server = @@session.collation_server;
SET @@session.collation_server = 'utf8_general_ci';



-- create & select db
CREATE DATABASE IF NOT EXISTS `meta_schema`
	DEFAULT CHARACTER SET = 'utf8'
	DEFAULT COLLATE = 'utf8_general_ci';


-- store metainfo about present lib

CREATE TABLE IF NOT EXISTS `meta_schema`.`LIBRARIES`
(
	`LIB_NAME`          VARCHAR(64)  NOT NULL  COMMENT 'Lib name',
	`LIB_VERSION`       VARCHAR(20)  NOT NULL  COMMENT 'Lib version',
	`LIB_MATURITY`      ENUM('dev', 'nightly', 'alpha', 'beta', 'gamma', 'rc', 'stable') 
	                                 NOT NULL  COMMENT 'Maturity level',
	`LIB_STATUS`        VARCHAR(80)  DEFAULT NULL  COMMENT 'Unused',
	`LIB_URL`           VARCHAR(80)  NULL      COMMENT 'Project page',
	`LIB_AUTHOR`        VARCHAR(64)  NULL      COMMENT 'Lib author(s)',
	`LIB_DESCRIPTION`   LONGTEXT     NOT NULL  COMMENT 'Explain lib',
	`LIB_LICENSE`       VARCHAR(80)  NOT NULL  COMMENT 'License name or URL of filename',
	PRIMARY KEY (`LIB_NAME`)
)
	ENGINE = InnoDB,
	DEFAULT CHARACTER SET = 'utf8',
	COMMENT   = 'Meta-info about Stored Programs libraries';


ALTER TABLE `meta_schema`.`LIBRARIES`
	/*M!
		ENGINE          = 'Aria',
		TRANSACTIONAL   = 1,
		PAGE_CHECKSUM   = 1,
		TABLE_CHECKSUM  = 1,
	*/
		MIN_ROWS  = 0;


REPLACE INTO `meta_schema`.`LIBRARIES`
	SET
		`LIB_NAME`         = 'STK/Unit',
		`LIB_VERSION`      = '1.0-rc6',
		`LIB_MATURITY`     = 'rc',
		`LIB_URL`          = 'http://stk.wikidot.com/stk-unit',
		`LIB_AUTHOR`       = 'STK Team',
		`LIB_DESCRIPTION`  = 'Unit Testing framework written in pure SQL',
		`LIB_LICENSE`      = 'GNU AGPL 3';


-- meta_schema mirrors
CREATE OR REPLACE VIEW `meta_schema`.`TEST_SUITE`
	AS (SELECT * FROM `stk_unit`.`TEST_SUITE`);
CREATE OR REPLACE VIEW `meta_schema`.`TEST_CASE`
	AS (SELECT * FROM `stk_unit`.`TEST_CASE`);
CREATE OR REPLACE VIEW `meta_schema`.`BASE_TEST`
	AS (SELECT * FROM `stk_unit`.`BASE_TEST`);


-- restore session variables
SET @@session.SQL_MODE = @__stk_u_old_SQL_MODE;
SET @@session.sql_warnings = @__stk_u_old_sql_warnings;
SET @@session.sql_notes = @__stk_u_old_sql_notes;
SET @@session.unique_checks = @__stk_u_old_unique_checks;
SET @@session.foreign_key_checks = @__stk_u_old_foreign_key_checks;
SET /*!50200  @@session.innodb_strict_mode = @__stk_u_old_innodb_strict_mode, */  @__stk_u_tmp = NULL;
SET /*M!      @@session.innodb_strict_mode = @__stk_u_old_innodb_strict_mode, */  @__stk_u_tmp = NULL;
SET @@session.updatable_views_with_limit = @__stk_u_updatable_views_with_limit;
SET @@session.character_set_server = @__stk_u_old_character_set_server;
SET @@session.collation_server = @__stk_u_old_collation_server;
-- free user variables
SET @__stk_u_old_SQL_MODE = NULL
	, @__stk_u_old_sql_warnings = NULL
	, @__stk_u_old_sql_notes = NULL
	, @__stk_u_old_unique_checks = NULL
	, @__stk_u_old_foreign_key_checks = NULL
	, @__stk_u_old_innodb_strict_mode = NULL
	, @__stk_u_updatable_views_with_limit = NULL
	, @__stk_u_old_character_set_server = NULL
	, @__stk_u_old_collation_server = NULL;


COMMIT;


##end

||
DELIMITER ;
